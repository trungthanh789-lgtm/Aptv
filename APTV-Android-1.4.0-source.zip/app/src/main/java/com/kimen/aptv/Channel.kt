package com.kimen.aptv

data class Channel(
    val name: String,
    val url: String,
    val group: String = "Khác",
    val logo: String = "",
    val tvgId: String = ""
)
