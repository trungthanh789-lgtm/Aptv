package com.kimen.aptv

object M3uParser {
    fun parse(text: String): List<Channel> {
        val lines = text.replace("\r", "").split("\n")
        val out = mutableListOf<Channel>()
        var name = ""; var group = ""; var logo = ""; var id = ""
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#EXTINF", true)) {
                val comma = line.indexOf(',')
                name = if (comma >= 0) line.substring(comma + 1).trim() else "Unknown"
                group = attr(line, "group-title").ifBlank { "Khác" }
                logo = attr(line, "tvg-logo")
                id = attr(line, "tvg-id")
            } else if (!line.startsWith("#") && name.isNotEmpty()) {
                out += Channel(name, line, group, logo, id)
                name = ""; group = ""; logo = ""; id = ""
            }
        }
        return out
    }
    private fun attr(s: String, key: String): String {
        val m = Regex("(?:^|\\s)$key=(?:\"([^\"]*)\"|\'([^\']*)\'|([^\\s]+))", RegexOption.IGNORE_CASE).find(s)
        return m?.groupValues?.drop(1)?.firstOrNull { it.isNotEmpty() } ?: ""
    }
}
