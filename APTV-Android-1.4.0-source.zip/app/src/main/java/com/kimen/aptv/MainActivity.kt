package com.kimen.aptv

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var list: ListView
    private lateinit var search: EditText
    private lateinit var groupSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var store: Store
    private var channels = listOf<Channel>()
    private var filtered = listOf<Channel>()
    private var mode = "all"
    private var loading = false
    private var adapter: ChannelAdapter? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        buildUi()
        val saved = store.playlist()
        if (saved.isNotBlank()) loadUrl(saved)
        else status.text = "Thiết lập URL playlist M3U để bắt đầu"
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(8,11,16)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,14,18,8); setBackgroundColor(Color.rgb(15,19,27)) }
        val title = TextView(this).apply { text = "APTV 1.4"; textSize = 26f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        val sub = TextView(this).apply { text = "Live TV • IPTV Player"; textSize = 12f; setTextColor(Color.LTGRAY) }
        header.addView(title); header.addView(sub)
        search = EditText(this).apply { hint = "Tìm kênh..."; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setPadding(12,0,12,0) }
        header.addView(search, LinearLayout.LayoutParams(-1,56)); root.addView(header)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(6,6,6,2) }
        val all = tab("Kênh"); val fav = tab("★ Yêu thích"); val history = tab("Lịch sử"); val settings = tab("⚙ Thiết lập")
        tabs.addView(all, LinearLayout.LayoutParams(0,50,1f)); tabs.addView(fav, LinearLayout.LayoutParams(0,50,1f)); tabs.addView(history, LinearLayout.LayoutParams(0,50,1f)); tabs.addView(settings, LinearLayout.LayoutParams(0,50,1f)); root.addView(tabs)

        groupSpinner = Spinner(this); root.addView(groupSpinner, LinearLayout.LayoutParams(-1,52))
        status = TextView(this).apply { setTextColor(Color.LTGRAY); setPadding(18,2,18,2) }; root.addView(status, LinearLayout.LayoutParams(-1,38))
        list = ListView(this).apply { dividerHeight = 0; setBackgroundColor(Color.rgb(8,11,16)); isFastScrollEnabled = true; clipToPadding = false; setPadding(8,6,8,8) }
        root.addView(list, LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)

        all.setOnClickListener { mode="all"; refresh(search.text.toString()) }
        fav.setOnClickListener { mode="fav"; refresh(search.text.toString()) }
        history.setOnClickListener { mode="history"; refresh(search.text.toString()) }
        settings.setOnClickListener { showSettings() }
        search.addTextChangedListener(SimpleWatcher { refresh(it) })
        groupSpinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { refresh(search.text.toString()) }
        }
        list.setOnItemClickListener { _,_,pos,_ ->
            if (pos >= filtered.size) return@setOnItemClickListener
            val c=filtered[pos]; store.addHistory(c.url)
            startActivity(Intent(this,PlayerActivity::class.java).apply {
                putExtra("name",c.name); putExtra("url",c.url); putExtra("logo",c.logo); putExtra("group",c.group); putExtra("tvgId",c.tvgId)
                putStringArrayListExtra("channelUrls", ArrayList(filtered.map { it.url }))
                putStringArrayListExtra("channelNames", ArrayList(filtered.map { it.name }))
                putExtra("channelIndex", pos)
            })
        }
    }

    private fun tab(s:String)=Button(this).apply { text=s; textSize=11f; isAllCaps=false; setTextColor(Color.WHITE); minHeight=0; minimumHeight=0 }

    private fun loadUrl(u:String){
        if (loading) return
        if(u.isBlank()){toast("Hãy nhập URL playlist M3U");return}
        loading=true; status.text="Đang tải playlist..."
        thread {
            try {
                val conn = (URL(u).openConnection() as HttpURLConnection).apply {
                    connectTimeout=15000; readTimeout=30000; requestMethod="GET"
                    setRequestProperty("User-Agent","APTV-Android/1.4")
                    setRequestProperty("Accept","*/*")
                }
                val code=conn.responseCode
                if(code !in 200..299) throw IllegalStateException("HTTP $code")
                val text=conn.inputStream.bufferedReader(Charsets.UTF_8).use{it.readText()}; conn.disconnect()
                val parsed=M3uParser.parse(text)
                if(parsed.isEmpty()) throw IllegalStateException("Playlist không có kênh hợp lệ")
                channels=parsed; store.savePlaylist(u)
                runOnUiThread { buildGroups(); refresh(""); status.text="${channels.size} kênh • ${channels.map{it.group}.distinct().size} nhóm" }
            } catch(e:Exception){ runOnUiThread { status.text="Không tải được playlist"; toast(e.message?:"Lỗi kết nối") } }
            finally { loading=false }
        }
    }

    private fun buildGroups(){
        val g=listOf("Tất cả")+channels.map{it.group.ifBlank{"Khác"}}.distinct().sorted(String.CASE_INSENSITIVE_ORDER)
        groupSpinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,g)
    }

    private fun refresh(q:String){
        val group=groupSpinner.selectedItem?.toString() ?: "Tất cả"
        val base=when(mode){
            "fav"->channels.filter{store.favorites().contains(it.url)}
            "history"->store.history().mapNotNull{u->channels.firstOrNull{it.url==u}}
            else->channels
        }
        filtered=base.filter{c->(q.isBlank()||c.name.contains(q,true)||c.group.contains(q,true))&&(group=="Tất cả"||c.group==group)}
        adapter = ChannelAdapter(this, filtered, store)
        list.adapter = adapter
    }

    private fun showSettings(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,10,24,10)}
        val p=EditText(this).apply{hint="URL playlist M3U";setSingleLine();setText(store.playlist())}
        val e=EditText(this).apply{hint="URL EPG XMLTV (tuỳ chọn)";setSingleLine();setText(store.epg())}
        box.addView(p);box.addView(e)
        AlertDialog.Builder(this).setTitle("Thiết lập APTV 1.4").setView(box)
            .setPositiveButton("Lưu"){_,_->store.savePlaylist(p.text.toString().trim());store.saveEpg(e.text.toString().trim());if(p.text.toString().isNotBlank())loadUrl(p.text.toString().trim())}
            .setNegativeButton("Hủy",null).show()
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    class SimpleWatcher(val f:(String)->Unit):android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,c:Int,d:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){f(s?.toString().orEmpty())};override fun afterTextChanged(e:android.text.Editable?) {}}
}
