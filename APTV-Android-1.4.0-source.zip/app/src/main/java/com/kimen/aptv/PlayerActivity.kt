package com.kimen.aptv

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.concurrent.thread
import java.net.HttpURLConnection
import java.net.URL

class PlayerActivity:AppCompatActivity(){
    private var player:ExoPlayer?=null; private lateinit var store:Store; private lateinit var info:TextView
    private var url=""; private var name=""; private var tvgId=""
    private var channelUrls = emptyList<String>()
    private var channelNames = emptyList<String>()
    private var channelIndex = -1
    override fun onCreate(b:Bundle?){
        super.onCreate(b); requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE; store=Store(this)
        url=intent.getStringExtra("url")?:""; name=intent.getStringExtra("name")?:"Kênh"; tvgId=intent.getStringExtra("tvgId")?:""
        channelUrls = intent.getStringArrayListExtra("channelUrls") ?: emptyList()
        channelNames = intent.getStringArrayListExtra("channelNames") ?: emptyList()
        channelIndex = intent.getIntExtra("channelIndex", -1)
        val group=intent.getStringExtra("group")?:""
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.BLACK)}
        val pv=PlayerView(this).apply{useController=true;keepScreenOn=true}; root.addView(pv,LinearLayout.LayoutParams(-1,0,1f))
        val bar=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(14,4,14,4);setBackgroundColor(Color.rgb(16,20,26))}
        info=TextView(this).apply{text="$name\n$group";setTextColor(Color.WHITE);textSize=15f}
        val fav=Button(this).apply{text=if(store.favorites().contains(url))"★" else "☆";isAllCaps=false}
        fav.setOnClickListener{fav.text=if(store.toggleFavorite(url))"★" else "☆"}
        val prev=Button(this).apply{text="‹";textSize=22f;isAllCaps=false}
        val next=Button(this).apply{text="›";textSize=22f;isAllCaps=false}
        prev.setOnClickListener{switchChannel(-1)}; next.setOnClickListener{switchChannel(1)}
        bar.addView(prev,LinearLayout.LayoutParams(54,72));bar.addView(info,LinearLayout.LayoutParams(0,72,1f));bar.addView(fav,LinearLayout.LayoutParams(58,72));bar.addView(next,LinearLayout.LayoutParams(54,72));root.addView(bar);setContentView(root)
        player=ExoPlayer.Builder(this).build().also{
            it.addListener(object:Player.Listener{
                override fun onPlayerError(error:PlaybackException){ info.text="$name\n⚠ Không phát được luồng: ${error.errorCodeName}" }
            })
            it.setMediaItem(MediaItem.fromUri(url));it.prepare();it.playWhenReady=true;pv.player=it
        }
        loadEpg(tvgId)
    }
    private fun switchChannel(delta:Int){
        if(channelUrls.isEmpty()) return
        val next = if(channelIndex < 0) 0 else (channelIndex + delta + channelUrls.size) % channelUrls.size
        url = channelUrls[next]; channelIndex = next; name = channelNames.getOrNull(next) ?: "Kênh"
        info.text = name
        player?.setMediaItem(MediaItem.fromUri(url)); player?.prepare(); player?.playWhenReady = true
    }
    private fun loadEpg(id:String){
        val epg=store.epg();if(epg.isBlank()||id.isBlank())return
        thread{try{val conn=(URL(epg).openConnection() as HttpURLConnection).apply{connectTimeout=10000;readTimeout=20000;setRequestProperty("User-Agent","APTV-Android/1.4")};val ps=conn.inputStream.use{EpgParser.parse(it)};conn.disconnect();val p=ps.firstOrNull{it.channelId==id&&it.containsNow()};if(p!=null)runOnUiThread{info.text="$name\n▶ ${p.title}"}}catch(_:Exception){}}
    }
    override fun onStop(){super.onStop();player?.release();player=null}
}
