package com.kimen.aptv

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.AbsListView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class ChannelAdapter(private val context: Context, private val items: List<Channel>, private val store: Store) : BaseAdapter() {
    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val c = items[position]
        val root = convertView as? LinearLayout ?: LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 10, 12, 10)
            background = GradientDrawable().apply {
                setColor(Color.rgb(18, 23, 31)); cornerRadius = 18f
            }
            layoutParams = AbsListView.LayoutParams(-1, 74)
        }
        root.removeAllViews()
        val logo = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setImageResource(android.R.drawable.ic_menu_gallery)
        }
        root.addView(logo, LinearLayout.LayoutParams(52, 52))
        val textBox = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(12,0,6,0) }
        val title = TextView(context).apply {
            text = if (store.favorites().contains(c.url)) "★ ${c.name}" else c.name
            setTextColor(Color.WHITE); textSize = 16f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val sub = TextView(context).apply { text = c.group.ifBlank { "Khác" }; setTextColor(Color.LTGRAY); textSize = 12f; maxLines = 1 }
        textBox.addView(title); textBox.addView(sub)
        root.addView(textBox, LinearLayout.LayoutParams(0, -1, 1f))
        if (c.logo.isNotBlank()) {
            thread {
                try {
                    val con = URL(c.logo).openConnection() as HttpURLConnection
                    con.connectTimeout = 5000; con.readTimeout = 7000; con.setRequestProperty("User-Agent", "APTV-Android/1.4")
                    val bmp = con.inputStream.use { BitmapFactory.decodeStream(it) }; con.disconnect()
                    if (bmp != null) logo.post { logo.setImageBitmap(bmp) }
                } catch (_: Exception) {}
            }
        }
        return root
    }
}
