package com.kimen.aptv

import org.w3c.dom.Element
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.xml.parsers.DocumentBuilderFactory

object EpgParser {
    data class Program(val channelId: String, val title: String, val start: String, val stop: String) {
        private fun parse(s: String): Long? = try {
            val base = s.take(14)
            val f = SimpleDateFormat("yyyyMMddHHmmss", Locale.US)
            f.timeZone = TimeZone.getTimeZone("UTC")
            f.parse(base)?.time
        } catch (_: Exception) { null }
        fun containsNow(now: Long = System.currentTimeMillis()): Boolean {
            val a = parse(start) ?: return false; val b = parse(stop) ?: return false
            return now in a..b
        }
    }
    fun parse(stream: InputStream): List<Program> {
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(stream)
        val nodes = doc.getElementsByTagName("programme")
        val out = ArrayList<Program>(nodes.length)
        for (i in 0 until nodes.length) {
            val e = nodes.item(i) as? Element ?: continue
            val title = e.getElementsByTagName("title").item(0)?.textContent?.trim().orEmpty()
            if (title.isNotBlank()) out += Program(e.getAttribute("channel"), title, e.getAttribute("start"), e.getAttribute("stop"))
        }
        return out.sortedBy { it.start }
    }
}
