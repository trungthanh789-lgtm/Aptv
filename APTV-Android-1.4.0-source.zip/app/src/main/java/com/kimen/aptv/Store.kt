package com.kimen.aptv

import android.content.Context
import org.json.JSONArray

class Store(context: Context) {
    private val p = context.getSharedPreferences("aptv", Context.MODE_PRIVATE)
    fun savePlaylist(url: String) { p.edit().putString("playlist", url).apply() }
    fun playlist(): String = p.getString("playlist", "") ?: ""
    fun saveEpg(url: String) { p.edit().putString("epg", url).apply() }
    fun epg(): String = p.getString("epg", "") ?: ""
    fun favorites(): MutableSet<String> = p.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
    fun toggleFavorite(url: String): Boolean {
        val s = favorites(); val added = s.add(url); if (!added) s.remove(url)
        p.edit().putStringSet("favorites", s).apply(); return added
    }
    fun history(): List<String> = try {
        val a = JSONArray(p.getString("history", "[]")); List(a.length()) { i -> a.getString(i) }
    } catch (_: Exception) { emptyList() }
    fun addHistory(url: String) {
        val old = history().filter { it != url }.toMutableList(); old.add(0, url)
        val a = JSONArray(); old.take(30).forEach { a.put(it) }
        p.edit().putString("history", a.toString()).apply()
    }
}
