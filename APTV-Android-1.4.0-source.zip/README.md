# APTV Android 1.3.0

Bản nâng cấp Android của APTV, mục tiêu Android 12+ và tối ưu cho điện thoại như Redmi Note 12 Pro 5G.

## Điểm mới 1.3
- versionCode 13 / versionName 1.3.0.
- Giao diện Live TV gọn hơn, có khu vực tìm kiếm, nhóm kênh, yêu thích, lịch sử và thiết lập.
- Player landscape, giữ màn hình sáng khi xem.
- Hiển thị lỗi phát luồng rõ hơn thay vì im lặng.
- Playlist HTTP/HTTPS kiểm tra HTTP status trước khi parse.
- User-Agent APTV-Android/1.3 và Accept header cho playlist/EPG.
- Kiểm tra playlist rỗng và tránh tải playlist trùng khi đang tải.
- EPG XMLTV hiển thị chương trình đang phát khi có tvg-id.
- Giữ Media3/ExoPlayer + HLS.

## Build
Mở thư mục `aptv_src` bằng Android Studio và chọn Build > Generate App Bundles or APKs > Generate APKs.

APK debug: `app/build/outputs/apk/debug/app-debug.apk`

APK release cần keystore ký ứng dụng. Không dùng keystore debug để phân phối chính thức.

Chỉ sử dụng playlist/luồng mà bạn có quyền truy cập.


## APTV 1.4.0
- Channel cards with logo loading and group labels.
- Previous/next channel controls in player.
- Version code 14 / version name 1.4.0.
- Media3 HLS player retained.
- Optimized for Android 12+ and touch/landscape playback.
