# Build APTV 1.3.0

1. Android Studio Ladybug hoặc mới hơn.
2. Open thư mục `aptv_src`.
3. Sync Gradle.
4. Build > Generate App Bundles or APKs > Generate APKs.
5. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.
6. Release: tạo keystore riêng rồi cấu hình signing trong Gradle; không phát hành bằng debug keystore.

Target: Android 35, minSdk 23, versionCode 13, versionName 1.3.0.
